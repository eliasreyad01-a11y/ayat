AYAT | آيات

التشغيل:
1) فك الضغط، وافتح index.html في Chrome أو Edge (يلزم اتصال بالإنترنت).
2) اضغط "تشغيل" ثم اختر القارئ والسورة من الشريط السفلي.

مصادر الصوت والنص (خارجية، اقرأ شروط استخدامها قبل أي إطلاق عام):
- الصوت: everyayah.com (آية بآية)
- النص العثماني: api.alquran.cloud

صور القرّاء (اختياري): ضع صورًا مرخّصة في img/reciters/ بهذه الأسماء:
afs.jpg  sds.jpg  shur.jpg  maher.jpg  ghamdi.jpg  dosari.jpg
basit.jpg  husary.jpg  minshawi.jpg  hudhaify.jpg  ajmi.jpg

الخلفيات: من الإعدادات > إضافة خلفية (رابط أو صورة من الجهاز).
